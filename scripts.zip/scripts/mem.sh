while true;
do ps -eo pid,user,cmd,%mem,%cpu --sort=-%mem | head >> process_memory.csv; 
sleep 1;
done
