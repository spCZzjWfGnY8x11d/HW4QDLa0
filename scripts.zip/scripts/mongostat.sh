#!/bin/bash
mongostat --all --noheaders >mongostat.csv