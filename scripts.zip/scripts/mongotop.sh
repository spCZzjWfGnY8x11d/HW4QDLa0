#!/bin/bash
mongotop  > mongotop.csv