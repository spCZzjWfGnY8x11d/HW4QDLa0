import csv
import pandas as pd
import numpy as np
import openpyxl
import argparse

# the constants
# usage: 用于确定输出文件的列名
AMF = 0
AUSF = 1
MONGODB = 2
NRF = 3
NSSF = 4
PCF = 5
SMF = 6 
UDM = 7
UDR = 8
UPF = 9

# 添加命令行参数
parser = argparse.ArgumentParser()
parser.add_argument("-i", "--input", help="输入的csv文件名", required=True)
args = parser.parse_args()

# 输入输出的文件名
CSV_INPUT=args.input
CSV_OUTPUT='./ok_'+CSV_INPUT[CSV_INPUT.rfind('/')+1:-4]+'.csv'
XLSX_OUTPUT=CSV_INPUT[:-4]+".xlsx"



COLUMN_NUM=10
ROW_NUM = 100000

# 读取CSV文件
# timestamp=[[0 for col in range(COLUMN_NUM)] for row in range(COLUMN_NUM)]
timestamp = np.zeros((ROW_NUM, COLUMN_NUM))
timeCnter=0
# timeString=""
with open(CSV_INPUT, 'r', newline='') as csvfile:
    reader = csv.reader(csvfile)
    
    for rawRow in reader:
        row="".join(rawRow).strip().split()
        # row="".join(row).split(',')     
        # print(timeCnter,type(row),len(row),row)
        # if len(row)<10:
        #     continue

        # 每一行数据被存储在一个列表中，可以通过索引来访问每一列数据
        if row[0]=='PID':
            timeCnter+=1
            continue
            # for i in range(10):
            #     timestamp[timeCnter][i]=0
            
# create a dictionary to map the row[10] values to the corresponding column index
        column_map = {
            "./bin/amf_modified": AMF,
            "./bin/ausf": AUSF,
            "/usr/bin/mongod": MONGODB,
            "./bin/nrf": NRF,
            "./bin/nssf": NSSF,
            "./bin/pcf": PCF,
            "./bin/smf": SMF,
            "./bin/smf_modified": SMF,
            "./bin/udm": UDM,
            "./bin/udr": UDR,
            "./bin/upf": UPF,
            "./bin/amf_modified": AMF,
            "./bin/amf_gcoff": AMF,
            "./bin/amf_gcdefault": AMF,
            "./bin/amf_formongo": AMF,
            "./bin/amf_sctp": AMF
        }

        if row[2] in column_map:
            timestamp[timeCnter][column_map[row[2]]] = row[-2]


# for i in range(timeCnter+1):
#     print(i,timestamp[i])
print(timeCnter)

# # 写入CSV文件
# with open(CSV_OUTPUT, 'w', newline='') as csvfile:
#     writer = csv.writer(csvfile)
#     # 通过writerow方法逐行写入数据
#     writer.writerow(["AMF","AUSF","MONGODB","NRF","NSSF","PCF","SMF","UDM","UDR","UPF"])
#     for i in range(timeCnter+1):
#         writer.writerow(timestamp[i])


# 将DataFrame写入XLSX文件
df = pd.DataFrame(timestamp[:timeCnter+1], columns=["AMF","AUSF","MONGODB","NRF","NSSF","PCF","SMF","UDM","UDR","UPF"])
df.to_excel(XLSX_OUTPUT, index=False)

print("success")