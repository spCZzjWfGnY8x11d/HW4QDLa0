#!/bin/bash
sar -n DEV 1 -o ./sar_output